import './head.dart';

void main() {
  runApp(MaterialApp(
    title: 'SIGTest',
    theme: ThemeData(
        fontFamily: 'suit',
        iconTheme: IconThemeData(
          size: 16,
        )
    ),
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<dynamic> pages = [
      new preview_step1(),
      new preview_step2(),
    ];
    int currentIndex = 0;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: SIGColors.primColor_bkf,
        leading: Container(
          margin: EdgeInsets.only(left: 24),
          child: Image.asset('assets/images/SIG_logo.png'),
        ),
        leadingWidth: 80,
        actions: [
          IconButton(
            onPressed: (){

            },
            icon: Icon(SIGicons.chatbubble_icon),
            iconSize: 24,
          ),
        ],
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 32, horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                    style: TextStyle(
                      fontSize: 24,
                      color: SIGColors.primColor_bkf,
                      fontWeight: FontWeight.w300,
                    ),
                    text: '지금 바로 도어 샘플을\n',
                    children: const [
                      TextSpan(
                        text: '쉽고 간편하게 살펴보세요',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                        ),
                      )
                    ]
                ),
              ),
              TextButton(
                onPressed: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => preview_step1())
                  );
                },
                child: Stack(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      height: 218,
                      child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                          ),
                          child: Image.asset('assets/images/frog.jpg',fit: BoxFit.fitWidth,)
                      ),
                    ),
                    Positioned(
                      right: 24,
                      bottom: 24,
                      child: Row(
                        children: [
                          RichText(
                              text: TextSpan(
                                  text: '주방',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 22,
                                    color: SIGColors.primColor_wf,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: ' 싱크장',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                      ),
                                    )
                                  ]
                              )
                          ),
                          Container(
                            width: 32,
                            height: 32,
                            margin: EdgeInsets.only(left: 16),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: SIGColors.primColor_wf,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(4)),
                            ),
                            child: Icon(
                              SIGicons.arrowright_icon,
                              color: SIGColors.primColor_wf,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: (){},
                child: Stack(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      height: 104,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(4)),
                        ),
                        child: Image.asset('assets/images/frog.jpg',fit: BoxFit.cover,),
                      ),
                    ),
                    Positioned(
                      right: 24,
                      bottom: 24,
                      child: Row(
                        children: [
                          RichText(
                              text: TextSpan(
                                  text: '현관',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 22,
                                    color: SIGColors.primColor_wf,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: ' 신발장',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                      ),
                                    )
                                  ]
                              )
                          ),
                          Container(
                            width: 32,
                            height: 32,
                            margin: EdgeInsets.only(left: 16),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: SIGColors.primColor_wf,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(4)),
                            ),
                            child: Icon(
                              SIGicons.arrowright_icon,
                              color: SIGColors.primColor_wf,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                          text: '견적내기\n',
                          style: TextStyle(
                            fontSize: 18,
                            color: SIGColors.primColor_bkf,
                            fontWeight: FontWeight.w700,
                          ),
                          children: <TextSpan> [
                            TextSpan(
                              text: '비교 불가! 저렴한 견적을 산출해 보세요',
                              style: TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 14,
                                color: SIGColors.primColor_bk40,
                              ),
                            )
                          ]
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: ElevatedButton(
                        onPressed: (){},
                        style: SIGButtonStyle.PrimOtlBtn_l,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset('assets/icons/Estimateicon.png'),
                            Text(
                              '맞춤 견적내기',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                          text: '추천 제품\n',
                          style: TextStyle(
                            fontSize: 18,
                            color: SIGColors.primColor_bkf,
                            fontWeight: FontWeight.w700,
                          ),
                          children: <TextSpan> [
                            TextSpan(
                              text: 'SIG에서 준비한 강력 추천상품',
                              style: TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 14,
                                color: SIGColors.primColor_bk40,
                              ),
                            )
                          ]
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: ElevatedButton(
                        onPressed: (){},
                        style: SIGButtonStyle.PrimOtlBtn_l,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset('assets/icons/Estimateicon.png'),
                            Text(
                              '견적내기',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: SIGColors.primColor_bk13)),
        ),
        child: BottomNavigationBar(
          onTap: (index) {
            setState(() => currentIndex = index);
          },
          currentIndex: _selectedIndex,
          items: [
            BottomNavigationBarItem(
              icon: Image.asset('assets/icons/Homeicon_un.png'),
              activeIcon: Image.asset('assets/icons/Homeicon.png'),
              label: '홈',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/icons/Estimateicon_un.png'),
              activeIcon: Image.asset('assets/icons/Estimateicon.png'),
              label: '견적내기',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/icons/Viewicon_un.png'),
              activeIcon: Image.asset('assets/icons/Viewicon.png'),
              label: '미리보기',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/icons/MyEstiicon_un.png'),
              activeIcon: Image.asset('assets/icons/MyEstiicon.png'),
              label: '내견적',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/icons/Mypageicon_un.png'),
              activeIcon: Image.asset('assets/icons/Mypageicon.png'),
              label: '내정보',
            ),
          ],
          type: BottomNavigationBarType.fixed,
          fixedColor: SIGColors.primColor_bkf,
          backgroundColor: SIGColors.primColor_wf,
          elevation: 0,
          selectedLabelStyle: TextStyle(
            fontWeight: FontWeight.w700,
          ),
          selectedFontSize: 12,
          unselectedItemColor: SIGColors.primColor_bk40,
          unselectedLabelStyle: TextStyle(
            fontWeight: FontWeight.w700,
          ),
          unselectedFontSize: 12,
          showUnselectedLabels: true,
        ),
      ),
    );
  }
}


// void _alertDialog(BuildContext, context) {
//   showDialog(
//     context: context,
//     builder: (BuildContext context) {
//       // return object of type Dialog
//       return AlertDialog(
//         title: new Text("Alert Dialog title"),
//         content: new Text("Alert Dialog body"),
//         actions: <Widget>[
//           new TextButton(
//             child: new Text("Close"),
//             onPressed: () {
//               Navigator.of(context).pop();
//             },
//           ),
//         ],
//       );
//     },
//   );
// }