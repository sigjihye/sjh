import 'package:sigmodern/head.dart';

class preview_step1 extends StatefulWidget {
  const preview_step1({Key? key}) : super(key: key);

  @override
  State<preview_step1> createState() => _preview_step1State();
}

class _preview_step1State extends State<preview_step1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        leading: IconButton(
          onPressed: (){
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => const main(),)
            // );
            Navigator.pop(context);
          },
          icon: Icon(SIGicons.arrowleft_icon),
          iconSize: 24,
          color: SIGColors.primColor_bkf,
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '구성 선택하기',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: SIGColors.primColor_bkf,
              ),
            ),
            Text(
              '미리 보고싶은 문짝의 구성을 선택하세요',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: SIGColors.primColor_bk80,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: (){
              print(context.findAncestorWidgetOfExactType<MaterialApp>());
              showDialog(context: context, builder: (context){
                return Dialog(
                  child: SelectionList(),
                  insetPadding: EdgeInsets.all(0),
                );
              });
            },
            child: Text('선택 목록'),
            style: SIGButtonStyle.pcBtn_s,
          ),
        ],
        shape: Border(
          bottom: BorderSide(
            color: SIGColors.primColor_bkf,
            width: 1,
          ),
        ),
        backgroundColor: SIGColors.primColor_wf,
        elevation: 0,
      ),
      // body: SizedBox.expand(
      //   child: DraggableScrollableSheet(
      //     builder: (BuildContext context, ScrollController scrollController) {
      //       return Container(
      //         color: Colors.blue[100],
      //         child: ListView.builder(
      //           controller: scrollController,
      //           itemCount: 25,
      //           itemBuilder: (BuildContext context, int index) {
      //             return ListTile(title: Text('Item $index'));
      //           },
      //         ),
      //       );
      //     },
      //   ),
      // ),
      body: Container(
        padding: EdgeInsets.only(left: 16, top: 32, right: 16, bottom: 0),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              // height: 200, // 임시로 줄여뒀음
              padding: EdgeInsets.all(32),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(4),),
                border: Border.all(color: SIGColors.primColor_bk13),
              ),
              child: SizedBox(
                child: Image.asset('assets/images/frog.jpg', width: double.infinity, fit: BoxFit.cover),
              ),
            ),
            Column(
              children: [
                Container(
                  width: double.infinity,
                  height: 70,
                  padding: EdgeInsets.symmetric(horizontal: 24),
                  margin: EdgeInsets.symmetric(vertical: 32),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: SIGColors.primColor_bk5,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '1단계',
                            style: TextStyle(
                              color: SIGColors.primColor_bk40,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            '구성 선택하기',
                            style: TextStyle(
                              color: SIGColors.primColor_bkf,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Container(
                //   child: Column(
                //     children: [
                //       ElevatedButton(
                //         onPressed: (){
                //           print('상부장 버튼');
                //         },
                //         child: Text('상부장'),
                //       ),
                //     ],
                //   ),
                //   // child: doorTypeList(),
                //   // child: Expanded(
                //   //   flex: 1,
                //   //   child: doorTypeTest(),
                //   // ),
                // ),
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: (){
                          print('상부장 버튼');
                        },
                        child: Text('상부장'),
                        style: SIGButtonStyle.PrimOtlBtn_l,
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.only(top: 16),
                      child: ElevatedButton(
                        onPressed: (){
                          print('하부장 버튼');
                        },
                        child: Text('하부장'),
                        style: SIGButtonStyle.PrimOtlBtn_l
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        // width: double.infinity,
        child: Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step2()));
                },
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      color: SIGColors.primColor_wf,
                    ),
                    text: '다음 단계',
                    children: [
                      TextSpan(
                        text: '(1/4)',
                        style: TextStyle(
                          color: SIGColors.primColor_w7,
                        ),
                      )
                    ],
                  ),
                ),
                style: SIGButtonStyle.PrimElevBtn_l,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class doorTypeList extends StatelessWidget {
  doorTypeList ({Key? key}) : super(key: key);

  var doorName = ['상부장', '하부장'];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, i){
        return OutlinedButton(
          onPressed: (){},
          child: Text(doorName[i]),
          style: SIGButtonStyle.PrimOtlBtn_l,
        );
      },
      itemCount: 2,
    );
  }
}