import 'package:sigmodern/head.dart';

class preview_step2 extends StatefulWidget {
  const preview_step2({Key? key}) : super(key: key);

  @override
  State<preview_step2> createState() => _preview_step2State();
}

class _preview_step2State extends State<preview_step2> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(
      length: 2,
      vsync: this,  //vsync에 this 형태로 전달해야 애니메이션이 정상 처리됨
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(SIGicons.arrowleft_icon),
          iconSize: 24,
          color: SIGColors.primColor_bkf,
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '유형 선택하기',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: SIGColors.primColor_bkf,
              ),
            ),
            Text(
              '문짝의 유형을 선택하세요',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: SIGColors.primColor_bk80,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: (){
              print(context.findAncestorWidgetOfExactType<MaterialApp>());
              showDialog(context: context, builder: (context){
                return Dialog(
                  child: SelectionList(),
                  insetPadding: EdgeInsets.all(0),
                );
              });
            },
            child: Text('선택 목록'),
            style: SIGButtonStyle.pcBtn_s,
          ),
        ],
        shape: Border(
          bottom: BorderSide(
            color: SIGColors.primColor_bkf,
            width: 1,
          ),
        ),
        backgroundColor: SIGColors.primColor_wf,
        elevation: 0,
      ),
      body: Container(
        padding: EdgeInsets.only(left: 0, top: 32, right: 0, bottom: 0),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 70,
              padding: EdgeInsets.symmetric(horizontal: 24),
              margin: EdgeInsets.only(left: 16, bottom: 32, right: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: SIGColors.primColor_bk5,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '2단계',
                        style: TextStyle(
                          color: SIGColors.primColor_bk40,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '유형 선택하기',
                        style: TextStyle(
                          color: SIGColors.primColor_bkf,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  TextButton(
                    onPressed: () => _moreMaterailBtn(context),
                    child: Row(
                      children: [
                        Text(
                          '더 알아보기',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: SIGColors.primColor_bkf,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        Icon(SIGicons.help_icon, size: 20, color: SIGColors.primColor_bkf),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: SIGColors.primColor_bk13)),
              ),
              child: TabBar(
                tabs: [
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '상부장',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700,),
                    ),
                  ),
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '하부장',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
                indicatorColor: SIGColors.primColor_bkf,
                labelColor: SIGColors.primColor_bkf,
                unselectedLabelColor: SIGColors.primColor_bk40,
                controller: _tabController,
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  Container(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Expanded(child: DoorPrdType(),)
                      ],
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Expanded(child: DoorPrdType(),)
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ]
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        // width: double.infinity,
        child: Row(
          children: [
            Container(
              margin: EdgeInsets.only(right: 8),
              child: OutlinedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step1()));
                },
                child: Text('이전'),
                style: SIGButtonStyle.PrimOtlBtn_l,
              ),
            ),
            Expanded(
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step3()));
                },
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      color: SIGColors.primColor_wf,
                    ),
                    text: '다음 단계',
                    children: [
                      TextSpan(
                        text: '(2/4)',
                        style: TextStyle(
                          color: SIGColors.primColor_w7,
                        ),
                      )
                    ],
                  ),
                ),
                style: SIGButtonStyle.PrimElevBtn_l,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// var MaterailName = ['PP', '지문방지 PET', 'PET', '우레탄'];
// var MeterailDesc = ['봄이 무성할 가슴속에 언덕 거외다. 아직 언덕 둘 까닭입니다. 풀이 별 하나에 동경과 이웃 아스라히 마리아 봅니다. 무성할 위에 어머니, 헤는 소학교 하나 까닭입니다.'];
final List<String> MaterailName = <String>['PP', '지문방지 PET', 'PET', '우레탄'];
final List<String> MeterailDesc = <String>['재질 desc 들어가는 곳 봄이 무성할 가슴속에 언덕 거외다. 아직 언덕 둘 까닭입니다.'];


void _moreMaterailBtn(BuildContext context){
  showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.only(topRight: Radius.circular(32), topLeft: Radius.circular(32)),
          ),
          padding: EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '제품 유형엔 어떤 것이 있나요?',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w200,),
              ),
              Container(
                // width: double.infinity,
                padding: EdgeInsets.all(24),
                color: SIGColors.primColor_bk3,
                margin: EdgeInsets.only(top: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'PP',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text(
                        '재질설명영역',
                        style: TextStyle(
                            color: SIGColors.primColor_bkf,
                            fontSize: 14
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // width: double.infinity,
                padding: EdgeInsets.all(24),
                color: SIGColors.primColor_bk3,
                margin: EdgeInsets.only(top: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '지문방지 PET',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text(
                        '재질설명영역',
                        style: TextStyle(
                            color: SIGColors.primColor_bkf,
                            fontSize: 14
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // width: double.infinity,
                padding: EdgeInsets.all(24),
                color: SIGColors.primColor_bk3,
                margin: EdgeInsets.only(top: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'PET',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text(
                        '재질설명영역',
                        style: TextStyle(
                            color: SIGColors.primColor_bkf,
                            fontSize: 14
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // width: double.infinity,
                padding: EdgeInsets.all(24),
                color: SIGColors.primColor_bk3,
                margin: EdgeInsets.only(top: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '우레탄',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 16),
                      child: Text(
                        '재질설명영역',
                        style: TextStyle(
                            color: SIGColors.primColor_bkf,
                            fontSize: 14
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // ListView.builder(
              //   itemBuilder: (context, index) {
              //     return Container(
              //       width: double.infinity,
              //       padding: EdgeInsets.all(24),
              //       color: SIGColors.primColor_bk3,
              //       margin: EdgeInsets.only(top: 16),
              //       child: Column(
              //         crossAxisAlignment: CrossAxisAlignment.start,
              //         children: [
              //           Text(
              //             '상부장',
              //             style: TextStyle(
              //               fontWeight: FontWeight.w700,
              //               fontSize: 24,
              //             ),
              //           ),
              //           // Text(MaterailName[i]),
              //           Padding(
              //             padding: EdgeInsets.only(top: 16),
              //             child: Text(
              //               '재질설명영역',
              //               style: TextStyle(
              //                   color: SIGColors.primColor_bkf,
              //                   fontSize: 14
              //               ),
              //             ),
              //           ),
              //         ],
              //       ),
              //     );
              //   },
              // ),
            ],
          ),
        );
      }
  );
}


enum PrdType {a, b, c, d}

class DoorPrdType extends StatefulWidget {
  DoorPrdType({Key? key}) : super(key: key);

  @override
  State<DoorPrdType> createState() => _DoorPrdTypeState();
}

class _DoorPrdTypeState extends State<DoorPrdType> {
  int _counter = 0;
  var _isChecked = false;
  var doorTypeName = ['PET', '지문방지 PET', 'PP', ',우레탄'];
  PrdType _door = PrdType.a; // 기본 선택

  // void _typeCounter() {
  //   setState(() {
  //     _counter++;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        RadioListTile(
          activeColor: SIGColors.pcColor_f,
          title: Text(
              'PET',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500
              )
          ),
          value: PrdType.a,
          groupValue: _door,
          onChanged: (value) {
            setState(() {
              // _highdoor = value;
            });
          },

        ),
        RadioListTile(
          activeColor: SIGColors.pcColor_f,
          title: Text(
              '지문방지 PET',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500
              )
          ),
          value: PrdType.b,
          groupValue: _door,
          onChanged: (value) {
            setState(() {
              // _highdoor = value;
            });
          },
        ),
        RadioListTile(
          activeColor: SIGColors.pcColor_f,
          title: Text(
              'PP',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500
              )
          ),
          value: PrdType.c,
          groupValue: _door,
          onChanged: (value) {
            setState(() {
              // _highdoor = value;
            });
          },
        ),
        RadioListTile(
          activeColor: SIGColors.pcColor_f,
          title: Text(
              '우레탄',
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500
              )
          ),
          value: PrdType.d,
          groupValue: _door,
          onChanged: (value) {
            setState(() {
              // _highdoor = value;
            });
          },
        ),
      ],
    );
  }
}