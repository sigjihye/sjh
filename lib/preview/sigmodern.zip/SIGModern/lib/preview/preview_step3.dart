import 'package:sigmodern/head.dart';

class preview_step3 extends StatefulWidget {
  const preview_step3({Key? key}) : super(key: key);

  @override
  State<preview_step3> createState() => _preview_step3State();
}

class _preview_step3State extends State<preview_step3> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(
      length: 2,
      vsync: this,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(SIGicons.arrowleft_icon),
          iconSize: 24,
          color: SIGColors.primColor_bkf,
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '색상 선택하기',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: SIGColors.primColor_bkf,
              ),
            ),
            Text(
              '문짝의 색상을 선택하세요',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: SIGColors.primColor_bk80,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: (){
              print(context.findAncestorWidgetOfExactType<MaterialApp>());
              showDialog(context: context, builder: (context){
                return Dialog(
                  child: SelectionList(),
                  insetPadding: EdgeInsets.all(0),
                );
              });
            },
            child: Text('선택 목록'),
            style: SIGButtonStyle.pcBtn_s,
          ),
        ],
        shape: Border(
          bottom: BorderSide(
            color: SIGColors.primColor_bkf,
            width: 1,
          ),
        ),
        backgroundColor: SIGColors.primColor_wf,
        elevation: 0,
      ),
      body: Container(
        // padding: EdgeInsets.symmetric(vertical: 32, horizontal: 24),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(left: 16, top: 32, right: 16, bottom: 0),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  border: Border.all(color: SIGColors.primColor_bk13),
                  borderRadius: BorderRadius.all(Radius.circular(4)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      flex: 1,
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(
                              color: SIGColors.primColor_bk13,
                              width: 1,
                            ),
                          )
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/images/frog.jpg',
                              width: double.infinity, fit: BoxFit.cover
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 8),
                              child: Column(
                                children: [
                                  Text(
                                    '상부장',
                                    style: TextStyle(
                                      color: SIGColors.primColor_bk40,
                                      fontSize: 12, fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Text(
                                    '레드월넛',
                                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700,),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: Container(
                        width: double.infinity,
                        padding:
                        EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/images/frog.jpg',
                              width: double.infinity, fit: BoxFit.cover,
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 8),
                              child: Column(
                                children: [
                                  Text(
                                    '상부장',
                                    style: TextStyle(
                                      color: SIGColors.primColor_bk40,
                                      fontSize: 12, fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Text(
                                    '레드월넛',
                                    style: TextStyle(
                                      fontSize: 14, fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    height: 70,
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    margin: EdgeInsets.symmetric(vertical: 32),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: SIGColors.primColor_bk5,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '3단계',
                              style: TextStyle(
                                color: SIGColors.primColor_bk40,
                                fontSize: 16, fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              '색상 선택하기',
                              style: TextStyle(
                                color: SIGColors.primColor_bkf,
                                fontSize: 18, fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: SIGColors.primColor_bk13))),
              child: TabBar(
                tabs: [
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '상부장[재질명]',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '하부장[재질명]',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
                indicatorColor: SIGColors.primColor_bkf,
                labelColor: SIGColors.primColor_bkf,
                unselectedLabelColor: SIGColors.primColor_bk40,
                controller: _tabController,
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  Container(
                    color: Colors.yellow[200],
                    alignment: Alignment.center,
                    child: Text('Tab1 View')),
                  Container(
                    color: Colors.green[200],
                    alignment: Alignment.center,
                    child: Text('Tab2 View'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        // width: double.infinity,
        child: Row(
          children: [
            Container(
              margin: EdgeInsets.only(right: 8),
              child: OutlinedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step2()));
                },
                child: Text('이전'),
                style: SIGButtonStyle.PrimOtlBtn_l,
              ),
            ),
            Expanded(
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step4()));
                },
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      color: SIGColors.primColor_wf,
                    ),
                    text: '다음 단계',
                    children: [
                      TextSpan(
                        text: '(3/4)',
                        style: TextStyle(
                          color: SIGColors.primColor_w7,
                        ),
                      )
                    ],
                  ),
                ),
                style: SIGButtonStyle.PrimElevBtn_l,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
