import 'package:sigmodern/head.dart';

class preview_step4 extends StatefulWidget {
  const preview_step4({Key? key}) : super(key: key);

  @override
  State<preview_step4> createState() => _preview_step4State();
}

class _preview_step4State extends State<preview_step4> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(
      length: 3,
      vsync: this,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(SIGicons.arrowleft_icon),
          iconSize: 24,
          color: SIGColors.primColor_bkf,
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '손잡이 선택하기',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: SIGColors.primColor_bkf,
              ),
            ),
            Text(
              '손잡이를 선택하세요',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: SIGColors.primColor_bk80,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: (){
              print(context.findAncestorWidgetOfExactType<MaterialApp>());
              showDialog(context: context, builder: (context){
                return Dialog(
                  child: SelectionList(),
                  insetPadding: EdgeInsets.all(0),
                );
              });
            },
            child: Text('선택 목록'),
            style: SIGButtonStyle.pcBtn_s,
          ),
        ],
        shape: Border(
          bottom: BorderSide(
            color: SIGColors.primColor_bkf,
            width: 1,
          ),
        ),
        backgroundColor: SIGColors.primColor_wf,
        elevation: 0,
      ),
      body: Container(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(left: 16, top: 32, right: 16, bottom: 0),
              width: double.infinity,
              child: Container(
                padding: EdgeInsets.all(24),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(4),),
                  border: Border.all(color: SIGColors.primColor_bk13),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 140, height: 140,
                      margin: EdgeInsets.only(right: 24),
                      child: Image.asset('assets/images/frog.jpg'),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '1구 - 9164',
                            style: TextStyle(
                              color: SIGColors.primColor_bkf,
                              fontWeight: FontWeight.w700, fontSize: 16,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 8, bottom: 24),
                            child: Text(
                              '가로 50, 세로 13, 높이 35(mm)',
                              style: TextStyle(
                                color: SIGColors.primColor_bk80,
                                fontWeight: FontWeight.w500, fontSize: 12,
                              ),
                            ),
                          ),
                          Column(
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(right: 32),
                                    child: Text(
                                      '재질',
                                      style: TextStyle(
                                        color: SIGColors.primColor_bk60,
                                        fontWeight: FontWeight.w500
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '황동',
                                    style: TextStyle(
                                      color: SIGColors.primColor_bk80,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  )
                                ],
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 16),
                                child: Row(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(right: 32),
                                      child: Text(
                                        '색상',
                                        style: TextStyle(
                                            color: SIGColors.primColor_bk60,
                                            fontWeight: FontWeight.w500
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '골드',
                                      style: TextStyle(
                                        color: SIGColors.primColor_bk80,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, height: 70,
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    margin: EdgeInsets.symmetric(vertical: 32),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: SIGColors.primColor_bk5,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '4단계',
                              style: TextStyle(
                                color: SIGColors.primColor_bk40,
                                fontSize: 16, fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              '손잡이 선택하기',
                              style: TextStyle(
                                color: SIGColors.primColor_bkf,
                                fontSize: 18, fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: SIGColors.primColor_bk13),
                ),
              ),
              child: TabBar(
                tabs: [
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '1구',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '2구',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                  Container(
                    height: 48,
                    alignment: Alignment.center,
                    child: Text(
                      '기타',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
                indicatorColor: SIGColors.primColor_bkf,
                labelColor: SIGColors.primColor_bkf,
                unselectedLabelColor: SIGColors.primColor_bk40,
                controller: _tabController,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        // width: double.infinity,
        child: Row(
          children: [
            Container(
              margin: EdgeInsets.only(right: 8),
              child: OutlinedButton(
                onPressed: (){
                  Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step3()));
                },
                child: Text('이전'),
                style: SIGButtonStyle.PrimOtlBtn_l,
              ),
            ),
            Expanded(
              child: ElevatedButton(
                onPressed: (){
                  // Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: preview_step3()));
                  print('선택완료');
                },
                child: RichText(
                  text: TextSpan(
                    style: TextStyle(
                      color: SIGColors.primColor_wf,
                    ),
                    text: '선택 완료',
                    children: [
                      TextSpan(
                        text: '(4/4)',
                        style: TextStyle(
                          color: SIGColors.primColor_w7,
                        ),
                      )
                    ],
                  ),
                ),
                style: SIGButtonStyle.PrimElevBtn_l,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
