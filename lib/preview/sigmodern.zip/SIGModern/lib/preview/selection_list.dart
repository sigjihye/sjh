import 'package:sigmodern/head.dart';

class SelectionList extends StatelessWidget {
  const SelectionList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            height: 80,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: SIGColors.primColor_bkf))
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '선택한 항목',
                  style: TextStyle(
                    color: SIGColors.primColor_bkf,
                    fontWeight: FontWeight.w700, fontSize: 22
                  ),
                ),
                IconButton(
                  onPressed: (){
                    Navigator.of(context).pop();
                  },
                  icon: Icon(SIGicons.clear_icon,size: 24),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                Column(
                  children: [
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        // color: Colors.teal,
                          border: BorderDirectional(bottom: BorderSide(color: SIGColors.primColor_bk5))
                      ),
                      padding: EdgeInsets.all(24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '1) 구성',
                                style: TextStyle(
                                    color: SIGColors.primColor_bk60
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 12),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                      margin: EdgeInsets.only(right: 8),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: SIGColors.primColor_bk13),
                                        borderRadius: BorderRadius.all(Radius.circular(4)),
                                      ),
                                      child: Text('상부장'),
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                      margin: EdgeInsets.only(right: 8),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: SIGColors.primColor_bk13),
                                        borderRadius: BorderRadius.all(Radius.circular(4)),
                                      ),
                                      child: Text('하부장'),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => preview_step1(),)
                              );
                            },
                            child: Text(
                              '수정',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: SIGColors.pcColor_f
                              ),
                            ),
                            // style: SIGButtonStyle.pcBtn_s,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        // color: Colors.teal,
                          border: BorderDirectional(bottom: BorderSide(color: SIGColors.primColor_bk5))
                      ),
                      padding: EdgeInsets.all(24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '2) 유형',
                                style: TextStyle(
                                    color: SIGColors.primColor_bk60
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 12),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          width : 50,
                                          child: Text('상부장'),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: SIGColors.primColor_bk13),
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          child: Text('재질타입'),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          width : 50,
                                          child: Text('하부장'),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: SIGColors.primColor_bk13),
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          child: Text('재질타입'),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => preview_step2(),)
                              );
                            },
                            child: Text(
                              '수정',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: SIGColors.pcColor_f
                              ),
                            ),
                            // style: SIGButtonStyle.pcBtn_s,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        // color: Colors.teal,
                          border: BorderDirectional(bottom: BorderSide(color: SIGColors.primColor_bk5))
                      ),
                      padding: EdgeInsets.all(24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '3) 색상',
                                style: TextStyle(
                                    color: SIGColors.primColor_bk60
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 12),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          width : 50,
                                          child: Text('상부장'),
                                        ),
                                        Container(
                                          width: 32,
                                          height: 32,
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              border: Border.all(color: SIGColors.primColor_bk13,)
                                          ),
                                          child: Image.asset('assets/images/frog.jpg'),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: SIGColors.primColor_bk13),
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          child: Row(
                                            children: [
                                              Text('재질타입'),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          width : 50,
                                          child: Text('하부장'),
                                        ),
                                        Container(
                                          width: 32,
                                          height: 32,
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              border: Border.all(color: SIGColors.primColor_bk13,)
                                          ),
                                          child: Image.asset('assets/images/frog.jpg'),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                          margin: EdgeInsets.only(right: 8),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: SIGColors.primColor_bk13),
                                            borderRadius: BorderRadius.all(Radius.circular(4)),
                                          ),
                                          child: Row(
                                            children: [
                                              Text('재질타입'),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => preview_step3(),)
                              );                            },
                            child: Text(
                              '수정',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: SIGColors.pcColor_f
                              ),
                            ),
                            // style: SIGButtonStyle.pcBtn_s,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        border: BorderDirectional(bottom: BorderSide(color: SIGColors.primColor_bk5)),
                      ),
                      padding: EdgeInsets.all(24),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '4) 손잡이',
                                style: TextStyle(
                                    color: SIGColors.primColor_bk60
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 12),
                                child: Column(
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Container(
                                            width: 80, height: 80,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: SIGColors.primColor_bk13),
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                            ),
                                            margin: EdgeInsets.only(right: 8),
                                            child: Image.asset('assets/images/frog.jpg')
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '전구 타입',
                                              style: TextStyle(
                                                  color: SIGColors.primColor_bk40,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 13
                                              ),
                                            ),
                                            Container(
                                              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                              margin: EdgeInsets.only(right: 8, top: 8),
                                              decoration: BoxDecoration(
                                                border: Border.all(color: SIGColors.primColor_bk13),
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                              ),
                                              child: Row(
                                                children: [
                                                  Text('재질타입'),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => preview_step4(),)
                              );                            },
                            child: Text(
                              '수정',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: SIGColors.pcColor_f
                              ),
                            ),
                            // style: SIGButtonStyle.pcBtn_s,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.all(16),
            width: double.infinity,
            child: Flexible(
              flex: 1,
              fit: FlexFit.tight,
              child: ElevatedButton(
                onPressed: (){
                  Navigator.pop(context);
                },
                child: Text('돌아가기'),
                style: SIGButtonStyle.PrimOtlBtn_l,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
